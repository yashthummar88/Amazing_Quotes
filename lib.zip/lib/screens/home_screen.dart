import 'dart:math';

import 'package:amazing_quotes/helper/image_helper.dart';
import 'package:amazing_quotes/helper/quotes_helper.dart';
import 'package:amazing_quotes/screens/category_screen.dart';
import 'package:amazing_quotes/screens/favourite_screen.dart';
import 'package:amazing_quotes/utils/utils.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Random random = Random();
  @override
  void initState() {
    dbh.initDB();
    dbi.initDB();
    super.initState();
  }

  int getRandomNumber() {
    int number = random.nextInt(10);
    return number;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.redAccent,
        title: Text(
          "Amazing Quotes",
          style: TextStyle(color: Colors.white, fontSize: 23, letterSpacing: 1),
        ),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) {
                    return FavouriteScreen();
                  }),
                );
              },
              icon: Icon(
                Icons.star,
                size: 28,
              )),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(top: 8, left: 8, right: 8),
          child: Column(
            children: [
              CarouselSlider(
                items: [
                  dbh.getDataById(id: getRandomNumber()),
                  dbh.getDataById(id: getRandomNumber()),
                  dbh.getDataById(id: getRandomNumber()),
                  dbh.getDataById(id: getRandomNumber()),
                ].map((e) {
                  return Builder(
                    builder: (context) {
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.symmetric(horizontal: 5),
                        decoration: BoxDecoration(
                          color: Colors.teal,
                        ),
                        child: Text("Text ${}"),
                      );
                    },
                  );
                }).toList(),
                options: CarouselOptions(
                  height: 200,
                  aspectRatio: 16 / 9,
                  viewportFraction: 0.8,
                  enableInfiniteScroll: false,
                  reverse: false,
                  autoPlay: true,
                  enlargeCenterPage: true,
                  autoPlayCurve: Curves.fastOutSlowIn,
                ),
              ),
              SizedBox(height: 5),
              Container(
                padding: EdgeInsets.only(top: 8, right: 10, left: 10),
                height: MediaQuery.of(context).size.height * 0.350,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Most Popular",
                      style: TextStyle(
                          fontSize: 15,
                          letterSpacing: 1.2,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 5),
                    Row(
                      children: [
                        getContainer(
                          context: context,
                          title: "Love Quotes",
                          image: "assets/images/q1.jpg",
                          type: "LOVE",
                          name: "Love",
                        ),
                        getContainer(
                          context: context,
                          title: "Swami\nVivekananda Quotes",
                          image: "assets/images/q2.jpg",
                          type: "LOVE",
                          name: "Swami Vivekananda",
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        getContainer(
                          context: context,
                          title: "Albert Einstein Quotes",
                          image: "assets/images/q3.jpg",
                          type: "LOVE",
                          name: "Albert Einstein",
                        ),
                        getContainer(
                          context: context,
                          title: "Motivational Quotes",
                          image: "assets/images/q4.jpg",
                          type: "LOVE",
                          name: "Motivational",
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(top: 8, right: 10, left: 10),
                height: MediaQuery.of(context).size.height * 0.4,
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Quotes by category",
                          style: TextStyle(
                              fontSize: 15,
                              letterSpacing: 1.2,
                              fontWeight: FontWeight.bold),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.of(context)
                                .pushNamed(CategoryScreen.routes);
                          },
                          child: Text(
                            "View All >",
                            style: TextStyle(
                                fontSize: 12, color: Colors.redAccent),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        getContainer(
                          context: context,
                          title: "Attitude Quotes",
                          image: "assets/images/q5.jpg",
                          type: "ATTITUDE",
                          name: "Attitude",
                        ),
                        getContainer(
                          context: context,
                          title: "Bravery Quotes",
                          image: "assets/images/q6.jpg",
                          type: "LOVE",
                          name: "Bravery",
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        getContainer(
                          context: context,
                          title: "Friendship Quotes",
                          type: "LOVE",
                          image: "assets/images/q7.jpg",
                          name: "Friendship",
                        ),
                        getContainer(
                          context: context,
                          title: "Hope Quotes",
                          image: "assets/images/q8.jpg",
                          type: "LOVE",
                          name: "Hope",
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
